"""demod is a python library for domestic energy modelling."""

