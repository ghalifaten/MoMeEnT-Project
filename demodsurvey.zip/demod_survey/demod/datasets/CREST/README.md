# CREST


CREST model was developped by Loughborough University, Leicestershire, UK
https://www.lboro.ac.uk/research/crest/

The CREST demand model can be accessed at
https://www.lboro.ac.uk/research/crest/demand-model/

Note that the CREST model is published under GNU General Public License 3
(http://www.gnu.org/licenses/).The license guarantees you the freedoms to use,
 study, share (copy), and modify the software. It is a copyleft license, which
means that you can distribute derived works only under the same license terms.


### Additional informations
The value of the pdf in the tpm has been slightly modified by a
rescaling so that the sum of the probabilities from one state to the others makes 1.
When there was not prob values from one state to any other, a default
value of 1 was set from this state to the same (no change of states,
stays on the same)

