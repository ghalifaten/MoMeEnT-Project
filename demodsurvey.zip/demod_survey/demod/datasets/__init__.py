from .GermanTOU.loader import GTOU
