Dataset for the weather.
https://www.renewables.ninja/documentation
We couuld add some compatibility with them.