This folder contains the dataset from http://www.tracebase.org/ .

Contains information from the tracebase data set, which is made available at http://www.tracebase.org under the Open Database License (ODbL)

Andreas Reinhardt, Paul Baumann, Daniel Burgstahler, Matthias Hollick, Hristo Chonov, Marc Werner, Ralf Steinmetz: On the Accuracy of Appliance Identification Based on Distributed Load Metering Data. Proceedings of the 2nd IFIP Conference on Sustainable Internet and ICT for Sustainability (SustainIT), 2012.
[https://www.areinhardt.de/publications/2012/Reinhardt_SustainIt_2012.pdf]